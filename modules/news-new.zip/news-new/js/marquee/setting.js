$(document).ready(function (){
  $("#marquee2").marquee({yScroll: "bottom"});
});