$(window).load(function(){	
	$(".newslider-vertical").sliderkit({
		shownavitems: 9,
		verticalnav: true,
		navitemshover: true,
		circular: true
	});
});	